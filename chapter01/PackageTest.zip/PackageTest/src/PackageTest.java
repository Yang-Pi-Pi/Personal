import course.*;
import student.*;
import teacher.*;

public class PackageTest{
public static void main (String[] args){
Student st = new Student();
Teacher te = new Teacher();
Course cs = new Course();
}
}
