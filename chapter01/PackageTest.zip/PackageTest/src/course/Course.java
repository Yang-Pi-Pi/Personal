package course;
public class Course{
         public Course(){
                 System.out.println("this is a course.");
}
}