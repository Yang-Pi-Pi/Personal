package student;
public class Student{
         public Student(){
                 System.out.println("this is a student.");
}
}