package teacher;
public class Teacher{
         public Teacher(){
                 System.out.println("this is a teacher.");
}
}